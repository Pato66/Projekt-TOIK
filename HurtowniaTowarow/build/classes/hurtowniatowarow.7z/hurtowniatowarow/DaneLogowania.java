/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hurtowniatowarow;

/**
 *
 * @author Patryk
 */
public class DaneLogowania {
    String login;
    String haslo;
    public DaneLogowania(String login, String haslo){
        this.login=login;
        this.haslo=haslo;
    }
    public String getLogin(){
        return this.login;
    }
     public String getPassword(){
        return this.haslo;
    }
}
