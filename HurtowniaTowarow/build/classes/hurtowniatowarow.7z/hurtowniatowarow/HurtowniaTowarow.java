package hurtowniatowarow;

public class HurtowniaTowarow {
    
    public static void main(String[] args) {

    }
}
