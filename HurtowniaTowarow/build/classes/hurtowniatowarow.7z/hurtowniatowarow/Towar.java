package hurtowniatowarow;

import java.util.ArrayList;
import java.util.List;

public class Towar {
    String nazwa;
    String ilosc;
    String cena;
    Towar(String a,String b,String c){
        nazwa=a;
        ilosc=b;
        cena=c;
    }
    Towar getTowar(){
        return this;
    }
//------------------------------------------------------------------------------
    public static double Round(double n,int k)
{
    double factor = Math.pow(10, k+1);
    n = Math.round(Math.round(n*factor)/10);
    return n/(factor/10);
}
//------------------------------------------------------------------------------
public static double oblicz_sume(ArrayList<Towar> wyniki){   
    double suma=0.0;
    for(int j=0;j<wyniki.size();j++){
            suma+=(Double.parseDouble(wyniki.get(j).ilosc) * Double.parseDouble(wyniki.get(j).cena));
        }
        System.out.println("Przed: "+suma);
        suma=Towar.Round(suma,2);
        System.out.println(suma); 
        return suma;
    }
//------------------------------------------------------------------------------
public static int seek(ArrayList<Towar> wyniki,String nazwa,String ilosc){
    int ktory=0;
    for(;ktory<wyniki.size()-1;ktory++){
        if(wyniki.get(ktory).nazwa == nazwa && wyniki.get(ktory).ilosc == ilosc){
            break;
        }
    }
    return ktory;        
    }

//------------------------------------------------------------------------------
public static void removeAll(ArrayList<Towar> wyniki){
    int ktory=0;
    for(;ktory<wyniki.size()-1;ktory++){
       wyniki.remove(ktory);
    }       
}
}