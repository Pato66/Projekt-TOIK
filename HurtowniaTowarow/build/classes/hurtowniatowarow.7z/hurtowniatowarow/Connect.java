package hurtowniatowarow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;

public class Connect {
    public String driver = "org.postgresql.Driver";
    public String host ="193.193.92.209:5434"; //"localhost";
    public String dbname = "2015_hudy_patryk";//"Kienci";
    public String user = "2015_hudy_patryk";//postgresql
    public String url = "jdbc:postgresql://" + host + "/" + dbname;
    private final String pass = "25930";//"gothic66"
    /*
    public String host ="localhost";
    public String dbname = "Klienci";
    public String user = "postgresql";
    public String url ="jdbc:postgresql://" + host + "/" + dbname;
    private final String pass = "gothic66";*/
    public Connection connection;
    public Connect() {
        connection = makeConnection();
    }
    public Connection getConnection() {
        return(connection); 
    }
    public void close() throws SQLException {
        connection.close();
    }
    //--------------------------------------------------------------------------------------------------------------------
    public Connection makeConnection() {
        try {
           // int id;
            //String imie, nazwisko;
            Class.forName(driver);
            Connection connection = DriverManager.getConnection(url, user, pass);
            System.out.println("Połączono z bazą " + dbname);
            Statement st = connection.createStatement();
            return(connection);
        }
        catch(ClassNotFoundException cnfe) {
            System.err.println("Blad ladowania sterownika: " + cnfe);
            return(null);
        }
        catch(SQLException sqle) {
            System.err.println("Blad przy nawiązywaniu polaczenia: " + sqle);
            return(null);
        }
    }
    //--------------------------------------------------------------------------------------------------------------------

    /**
     *
     * @throws SQLException
     */
    public void selectFromDatabase() throws SQLException{
            int id;
            String imie,nazwisko,login,haslo,email;
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM hurtownia.klienci");
            while (rs.next()) {
                id = rs.getInt("id_klienta");
                imie = rs.getString("imie");
                nazwisko = rs.getString("nazwisko");
                login=rs.getString("login");
                haslo=rs.getString("haslo");
                email=rs.getString("email");
                
                System.out.print("ID: " + id);
                System.out.print(", Name: " + imie);
                System.out.print(", Surname: " + nazwisko);
                System.out.print("Login: " + login);
                System.out.print("haslo: " + haslo);
                System.out.print("email: " + email);
            }
            rs.close();
            st.close();
    }
    //-------------------------------------------------------------------------------------------------------------------
    public boolean checkUser(String nick,String password) throws SQLException{
        String dNick="",dPass="";
        Statement st= connection.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM hurtownia.klienci WHERE login='"+nick+"';");
        while(rs.next()){
            dNick=rs.getString("login");
            dPass=rs.getString("haslo");
        }
        if(dNick=="" || dPass==""){
            return false;
        }
        if(nick.equals(dNick) && password.equals(dPass)){
            System.out.println("Znaleziono usera");
             st.close();
            return true;
        }
        else{
            System.out.println("Nie znaleziono usera");
             st.close();
            return false;
        }              
    }
    //--------------------------------------------------------------------------------------------------------------------
    public boolean checkLogin(String log)throws SQLException{
        boolean flaga=true;
        try{
            Statement st = connection.createStatement();
            ResultSet rs= st.executeQuery("SELECT login FROM hurtownia.klienci");
            while(rs.next()){
                if(log.equals(rs.getString("login"))){
                    flaga=false;
                }
            }
         }catch (SQLException ex) {
            System.out.println("Login zajety");
        }
        return flaga;
    }
    //-------------------------------------------------------------------------------------------------------------------
    public void  addToDatabase(String login,String haslo,String nowe_imie, String nowe_nazwisko,String email,int adres) throws SQLException
    {
        try{
            Statement st = connection.createStatement();
            String liczba="";
            int max=0;
            ResultSet rs= st.executeQuery("SELECT id_klienta FROM hurtownia.klienci ORDER BY id_adresu DESC LIMIT 1");
            while(rs.next()){
                liczba=rs.getString("id_klienta");
            }
              max=Integer.parseInt(liczba)+1;
            st.executeUpdate("INSERT INTO hurtownia.klienci (id_klienta,login, haslo, imie, nazwisko,email,id_adresu)"
                            + " VALUES ("+max+",'"+login+"','"+haslo+"','"+ nowe_imie+"','"+ nowe_nazwisko+"','"+email+"',"+adres+");");
            st.close();
            System.out.println("Dodano klienta");
        }catch (SQLException ex) {
            System.out.println("Nie dodano klienta");
        }
    }
     //--------------------------------------------------------------------------------------------------------------------
    public int  addToAddress(String kraj,String wojewodztwo,String miejscowosc, String ulica,String numerDomu)throws SQLException
    {
        int max=0;
        try{
            System.out.println("--------------addToAdress--------------------");
            Statement st = connection.createStatement();
            String liczba="";
             System.out.println("przed result set");
            ResultSet rs= st.executeQuery("SELECT id_adresu FROM hurtownia.adresy ORDER BY id_adresu DESC LIMIT 1");
            System.out.println("po result set");
            while(rs.next()){
                liczba=rs.getString("id_adresu");
            }
            max=Integer.parseInt(liczba)+1;
            ResultSet rs2= st.executeQuery("INSERT INTO hurtownia.adresy (id_adresu,kraj,wojewodztwo,miejscowosc,ulica,nr_domu) "
                    + "VALUES ("+max+",'"+kraj+"','"+ wojewodztwo+"','"+miejscowosc +"','"+ ulica+"','"+numerDomu +"');");
            st.close();
            return max;
        }catch (SQLException ex) {
            //System.out.println("Nie dodano adresu");
            return max;
        }
       
    }
    //---------------------------------------------------------------------------------------------------------------------
    public Towar searchPhrase(String doWyszukania) throws SQLException{
        String nazwa="",ilosc="",cena="";
        Statement st= connection.createStatement();
        //ResultSet rs = st.executeQuery("SELECT * FROM hurtownia.towary WHERE nazwa_towaru='"+doWyszukania+"';");
         ResultSet rs = st.executeQuery("SELECT * FROM hurtownia.towary WHERE nazwa_towaru LIKE '%"+doWyszukania+"%';");
        while(rs.next()){
            nazwa=rs.getString("nazwa_towaru");
            ilosc=rs.getString("ilosc");
            cena=rs.getString("cena");
        }
        Towar t=new Towar(nazwa,ilosc,cena);
        return t;
    }
    //---------------------------------------------------------------------------------------------------------------------
    public boolean checkAvailability(String nazwa,String ilosc) throws SQLException{
        String ileMagazyn="";
        Statement st= connection.createStatement();
        ResultSet rs = st.executeQuery("SELECT ilosc FROM hurtownia.towary WHERE nazwa_towaru='"+nazwa+"';");
        while(rs.next()){
             ileMagazyn=rs.getString("ilosc");
         }
        if(Integer.parseInt(ileMagazyn)>= Integer.parseInt(ilosc)){
            st.executeUpdate("UPDATE hurtownia.towary SET ilosc="+(Integer.parseInt(ileMagazyn)-Integer.parseInt(ilosc))+
                             "WHERE nazwa_towaru='"+nazwa+"';");
            return true;
        }
        else{
            return false;
        }
         
    }
    //---------------------------------------------------------------------------------------------------------------------
    public void removeFromBasket(String nazwa,String ilosc) throws SQLException{
        String ileMagazyn="";
        Statement st= connection.createStatement();
        ResultSet rs = st.executeQuery("SELECT ilosc FROM hurtownia.towary WHERE nazwa_towaru='"+nazwa+"';");
        while(rs.next()){
             ileMagazyn=rs.getString("ilosc");
        }
        st.executeUpdate("UPDATE hurtownia.towary SET ilosc="+(Integer.parseInt(ileMagazyn)+Integer.parseInt(ilosc))+
                         "WHERE nazwa_towaru='"+nazwa+"';");
    }
    //---------------------------------------------------------------------------------------------------------------------
     public ArrayList searchPhrase2(String doWyszukania) throws SQLException{
        String nazwa="",ilosc="",cena="";
        ArrayList<Towar> towary=new ArrayList<Towar>();
        Statement st= connection.createStatement();
         ResultSet rs = st.executeQuery("SELECT * FROM hurtownia.towary WHERE nazwa_towaru LIKE '%"+doWyszukania+"%';");
        while(rs.next()){
            nazwa=rs.getString("nazwa_towaru");
            ilosc=rs.getString("ilosc");
            cena=rs.getString("cena");
            Towar t=new Towar(nazwa,ilosc,cena);
            towary.add(t);
        }
        System.out.println(towary.size());
        return towary;
    }
    //---------------------------------------------------------------------------------------------------------------------
     public void makeOrder(ArrayList<Towar> wyniki, String login) throws SQLException{
         Statement st= connection.createStatement();
         int max=0;
         String liczba="",id="",id_towaru="";
         ResultSet rs= st.executeQuery("SELECT id_zamowienia FROM hurtownia.zamowienia ORDER BY id_zamowienia DESC LIMIT 1");
         while(rs.next()){
             liczba=rs.getString("id_zamowienia");
         }
         max=Integer.parseInt(liczba)+1;
         System.out.println("MAX: "+max);
         ResultSet rs2=st.executeQuery("SELECT * FROM hurtownia.klienci WHERE login='"+login+"';");
         while(rs2.next()){
            id=rs2.getString("id_klienta");
         }
         st.execute("INSERT INTO hurtownia.zamowienia VALUES("+max+","+Integer.parseInt(id)+",CURRENT_DATE,'w realizacji');");

         System.out.println("Przed for size="+wyniki.size());
         for(int k=0;k<wyniki.size();k++){
            System.out.println("pocz");
            ResultSet rs3=st.executeQuery("SELECT * FROM hurtownia.towary WHERE nazwa_towaru='"+wyniki.get(k).nazwa+"';");
            System.out.println("przed while");
            while(rs3.next()){
               System.out.println("petla...");
               id_towaru=rs3.getString("id_towaru");
               System.out.println("po id_towaru... "+id_towaru);
            }
            //id_towaru=Integer.toString(k);
            System.out.println("ID_TOWARU: "+id_towaru);
            st.execute("INSERT INTO hurtownia.szczegoly_zamowienia VALUES("+max+","+Integer.parseInt(id_towaru)
                      +","+Integer.parseInt(id)+","+wyniki.get(k).ilosc+","+wyniki.get(k).cena+");");
         }
         System.out.println("--------------KONIEC-----------");
     }
    //--------------------------------------------------------------------------------------------------------------------
    public boolean CheckData(String email,String ulica, String nrDomu) throws SQLException{
         Statement st= connection.createStatement();
         String adresEmail="";
         ResultSet rs= st.executeQuery("SELECT email,ulica,nr_domu FROM hurtownia.klienci,hurtownia.adresy "
                 + "WHERE klienci.id_adresu=adresy.id_adresu and email='"+email+"' and ulica='"+ulica+"' and nr_domu='"+nrDomu+"';");
         while(rs.next()){
             adresEmail=rs.getString("email");
         }
         if(adresEmail == ""){
             return false;
         }
         else{
             return true;
         }
    }
    public DaneLogowania giveLOginAndPassword(String email,String ulica, String nrDomu) throws SQLException{
        Statement st= connection.createStatement();
         String log="",pass="";
         ResultSet rs= st.executeQuery("SELECT login,haslo FROM hurtownia.klienci,hurtownia.adresy "
                 + "WHERE klienci.id_adresu=adresy.id_adresu and email='"+email+"' and ulica='"+ulica+"' and nr_domu='"+nrDomu+"';");
         while(rs.next()){
             log=rs.getString("login");
             pass=rs.getString("haslo");
         }
        return new DaneLogowania(log,pass);
    }
    //---------------------------------------------------------------------------------------------------------------------
    public static void main(String[] args) {
         SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Connect  okienko = new Connect();
                okienko.makeConnection();
                try {                          
                    okienko.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
}
